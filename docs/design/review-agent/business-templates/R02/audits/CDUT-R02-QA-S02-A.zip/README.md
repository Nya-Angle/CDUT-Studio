# CDUT-R02-QA-S02-A

- 研究日期：2026-10-24。
- 仓库：`Fuck-GH-Admin/cdut-studio-review-agent`。
- 分支：`feat/v3-r02/templates-S02-A`。
- PR：[#244 feat(review-v3): implement R02 templates S02-A](https://github.com/Fuck-GH-Admin/cdut-studio-review-agent/pull/244)。
- 原件权威分支：`feat/v3-r02-template-library`；原稿均按当前分支 HEAD 读取，未要求或依赖 ZIP。
- 审查报告使用的原件 HEAD：`150acfe761cb7ad0424a2ca009fd57f12dbfddfd`。
- 实施首个提交：`2d30608521424a64710b33ad58dca35218014d94`；审查报告/问题台账提交：`b9aa1952452391c25c6890ade289bbe7c7c05fcc`。

## 包内文件
- `AUDIT-S02-A.md`：五份模板的独立质量结论、政策证据、问题、跨模板冲突、官方来源 URL 和测试限制。
- `ISSUES-S02-A.tsv`：固定列名的问题台账；16 条问题。
- `STATUS-S02-A.tsv`：五份模板一行一条的机器可读状态表。
- `patches/S02-T03.md`、`patches/S02-T04.md`、`patches/S02-T05.md`：完整审核后 Markdown 修订稿，不是 diff。T01/T02 没有需要安全改写业务正文的补丁。
- 原始研究原件位于仓库 `research-original/`，未被覆盖；patches 是审核后副本，和原件分离。

## 来源范围
官方来源包括成都理工大学 2019 本科学生学籍管理办法、2022 来华留学生管理规定、2024–2025/2025–2026 指定学期考试通知、教育部令第41号、四川省 2026 自考课程免试规则及当期通知、四川省 2027 研考公告/FAQ，以及成都理工大学研究生/国际教育/合作办学政策目录线索。具体 URL、文号、条款、日期、适用范围和访问限制见 `AUDIT-S02-A.md`。

## 状态与限制
- 五份质量状态均为 `PASS_WITH_WARNINGS`；T01–T04 政策证据为 `PARTIAL`，T05 为 `UNCONFIRMED`。
- 不把目录、搜索片段或旧学期通知包装成当前制度；不编造学校授权、阈值、表单、系统入口或最终批准角色。
- 所有运行时定义保持 `draft`、`policyVersionIds: []`、`policyRefs: []`、`autoPassPolicy.enabled: false`，本地人工复核，不做学校远端回写。
- 本地执行环境没有 Bun（`bun: command not found`），所以批次测试、`bun run typecheck`、`bun run check:boundaries` 没有本地通过结果。PR 打开时 GitHub Actions 为 queued；本 ZIP 生成时仍未把 CI 说成通过。最终应以 PR #244 实际检查结果为准。
- 本批没有修改共享注册器、template-store、shared 类型、V3 核心服务、IPC、preload、renderer、README 或 AGENTS。共享接线由唯一集成 Owner 完成。
